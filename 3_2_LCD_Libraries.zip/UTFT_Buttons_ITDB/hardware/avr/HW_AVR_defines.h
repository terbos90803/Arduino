#define bitmapdatatype unsigned int*
